-- phpMyAdmin SQL Dump
-- version 4.4.13.1
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Sep 07, 2015 at 10:24 AM
-- Server version: 10.0.20-MariaDB
-- PHP Version: 5.6.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `obama`
--

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE IF NOT EXISTS `contents` (
  `id` int(10) unsigned NOT NULL,
  `content` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `content`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Nguồn điện từ gió rất quan trọng với nước Mỹ, nên tôi cần những người chém gió giỏi như {hoten}.', 2, '2015-09-05 18:30:13', '2015-09-05 20:03:45'),
(2, 'Tôi đề nghị chức Ngoại trưởng  Mỹ ngày mai sẽ được giao cho {hoten}', 2, '2015-09-05 18:48:10', '2015-09-05 18:48:10'),
(3, 'Ngày mai {hoten} sẽ nhận được giấy khen từ tôi vì sự nổ lực cống hiến trong những năm qua.', 2, '2015-09-05 20:06:04', '2015-09-05 20:06:04'),
(4, 'Tôi thực sự tự hào về {hoten}, đất nước chúng ta có  ngày hôm nay là vì nhờ công {hoten}.', 2, '2015-09-05 20:06:20', '2015-09-06 08:49:15'),
(5, 'Tôi đề nghị {hoten} thu xếp công việc để chúng ta có một buổi gặp gỡ thân mật.', 2, '2015-09-05 20:06:37', '2015-09-05 20:06:37'),
(6, 'Cháu ngoại của tôi sẽ được đặt tên theo {hoten}, {hoten} vui lòng vì điều đấy.', 2, '2015-09-07 09:04:42', '2015-09-07 09:04:42'),
(7, 'Nước mỹ sẽ chậm phát triển nếu thiếu nhân tài như {hoten}.', 2, '2015-09-07 09:05:00', '2015-09-07 09:05:00'),
(8, 'Không có gì là hoàn hảo 100% cho đến khi tôi gặp {hoten}. Một người tuyệt vời.', 2, '2015-09-07 09:05:21', '2015-09-07 09:05:21'),
(9, 'Thật đáng vinh hạnh được gặp {hoten}, họa sĩ nổi tiếng thế giới, tôi có thể mua bức họa của {hoten} với giá tỷ đô.', 2, '2015-09-07 09:06:27', '2015-09-07 09:06:27'),
(10, 'Tôi chỉ sẽ mang nhãn hiệu đồ lót của nhà thiết kế {hoten} dành riêng cho tôi.', 2, '2015-09-07 09:06:55', '2015-09-07 09:06:55'),
(11, 'Tôi đề nghị {hoten} ngày mai sẽ giữ chức Bộ trưởng y tế vì đã giúp con Waki  nhà tôi ị được sáng nay.', 2, '2015-09-07 09:07:21', '2015-09-07 09:07:21'),
(12, 'Bài phát biểu của {hoten} tại nhà trắng về Quyền tự sướng của con người thật sự xuất sắc và đáng kinh ngạc.', 2, '2015-09-07 09:07:40', '2015-09-07 09:07:40'),
(13, 'Thần đồng máy tính {hoten} vừa sáng tạo ra chiếc máy hoạt động theo não bộ có thế xứng ngang hàng Steve Job lừng danh.', 2, '2015-09-07 09:08:04', '2015-09-07 09:08:04'),
(14, 'Tàu vũ trụ do phi hành gia {hoten} điều khiển đã đặt chân đến Mặt trời, điều này đánh dấu mốc phát triển lịch sử ngành công nghệ vũ trụ nước Mỹ.', 2, '2015-09-07 09:08:37', '2015-09-07 09:08:37');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2015_09_05_162257_create_contents_table', 2),
('2015_09_06_120336_create_results_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE IF NOT EXISTS `results` (
  `id` int(10) unsigned NOT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id`, `full_name`, `gender`, `content_id`, `created_at`, `updated_at`) VALUES
(1, 'Tran Van Lanh', 'male', 3, '2015-09-06 06:16:17', '2015-09-06 06:16:17'),
(2, 'Tran Van Lanh', 'female', 3, '2015-09-06 06:49:26', '2015-09-06 06:49:26'),
(3, 'Tran Van Lanh', 'female', 5, '2015-09-06 06:51:06', '2015-09-06 06:51:06'),
(4, 'Tran Van Lanh', 'male', 4, '2015-09-06 08:48:27', '2015-09-06 08:48:27'),
(5, 'Tran Van Lanh', 'male', 2, '2015-09-07 08:45:26', '2015-09-07 08:45:26'),
(6, 'Tran Van Lanh', 'male', 3, '2015-09-07 08:48:55', '2015-09-07 08:48:55'),
(7, 'Tran Van Lanh', 'male', 1, '2015-09-07 08:51:31', '2015-09-07 08:51:31'),
(8, 'Tran Van Lanh', 'male', 2, '2015-09-07 08:53:41', '2015-09-07 08:53:41'),
(9, 'Tran Van Lanh', 'male', 4, '2015-09-07 08:55:07', '2015-09-07 08:55:07'),
(10, 'Tran Van Lanh', 'male', 2, '2015-09-07 08:59:16', '2015-09-07 08:59:16'),
(11, 'Tran Van Lanh', 'female', 3, '2015-09-07 08:59:55', '2015-09-07 08:59:55'),
(12, 'Tran Van Lanh', 'female', 4, '2015-09-07 09:00:09', '2015-09-07 09:00:09');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@obama.com', '$2y$10$sv1vbKWrDQCnaMwqN9WIM.LDnzeH79ch1UcVD.pvZa.vDDb4JVuaa', NULL, '2015-09-05 01:52:01', '2015-09-05 01:52:01'),
(2, 'LanhTV', 'vanlanh10273@gmail.com', '$2y$10$JAe6pQTODjVPQD.aKYfaCO2uBGW412n4J.mEdnQ5H2HZwXiDUhXf2', 'IHTGh2gXXRz7IgzCL1Hyc0d3WQKx83PLVjIItJ42KafhYgkr03yihyST0YgI', '2015-09-05 01:52:01', '2015-09-05 20:04:00'),
(3, 'HienPD', 'hienpd@gmail.com', '$2y$10$p.yHSMXWkx99y5eTKoiHZuiMwDeWExR0lmPdVd61ou8yO34ygUXIW', NULL, '2015-09-05 01:52:02', '2015-09-05 01:52:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contents`
--
ALTER TABLE `contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contents`
--
ALTER TABLE `contents`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
